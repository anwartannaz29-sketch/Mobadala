import kivy 
from kivy.app import App 
from kivy.uix.label import Label 
from kivy.core.window import Window 
from kivy.uix.button import Button 
from kivy.graphics import Rectangle 
from kivy.uix.floatlayout import FloatLayout 
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout 

class Menu(Screen):
    def __init__(self , **kwargs ):
        super().__init__(**kwargs )
        layout = BoxLayout(
        orientation='vertical')
        with  layout.canvas.before:
            self.bg = Rectangle(source="bk.jpg", pos=layout.pos, size=layout.size)

        layout.bind(size=self.update_bg, pos=self.update_bg)
        self.lb =Label(
        text="Welcome Safae", 
        font_name='Pano.ttf',
        color = (0.3,0.1,0.4,1)
        )
        layout.add_widget(self.lb)
        self.add_widget(layout)
    def update_bg(self, instance, value):
        self.bg.pos = instance.pos
        self.bg.size = instance.size
class Mylove(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(Menu(name='menu'))
        return sm
if __name__=='__main__':
          Mylove().run()       
          