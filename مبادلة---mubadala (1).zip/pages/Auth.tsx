
import React, { useState } from 'react';
import { AcademicCapIcon, DevicePhoneMobileIcon, EnvelopeIcon, LockClosedIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import { SparklesIcon } from '@heroicons/react/24/solid';

interface AuthProps {
  onLogin: (userData: any) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [method, setMethod] = useState<'email' | 'phone'>('email');
  const [isLoading, setIsLoading] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onLogin({
        id: 'u1',
        name: 'أحمد محمود',
        avatar: 'https://picsum.photos/id/64/200/200',
        points: 10,
        // ... rest of user data
      });
    }, 1500);
  };

  const handleGoogleLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin({ id: 'u1', name: 'أحمد محمود (عبر جوجل)', avatar: 'https://picsum.photos/id/64/200/200' });
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-5xl w-full grid md:grid-cols-2 bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-gray-100">
        
        {/* Left Side: Brand & Marketing */}
        <div className="hidden md:flex flex-col justify-between p-12 bg-emerald-600 text-white relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-12">
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                <AcademicCapIcon className="h-8 w-8" />
              </div>
              <span className="text-2xl font-black">مبادلة</span>
            </div>
            
            <h1 className="text-5xl font-black mb-6 leading-tight">
              ابدأ رحلة <br/> التعلم المجاني <br/> اليوم.
            </h1>
            <p className="text-emerald-50 text-lg opacity-90 leading-relaxed max-w-xs">
              انضم لأكبر مجتمع عربي لتبادل الخبرات. علم غيرك، واكتسب مهارات جديدة برصيد ساعاتك.
            </p>
          </div>

          <div className="relative z-10 bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/10">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-yellow-400 p-1.5 rounded-lg shadow-lg">
                <SparklesIcon className="h-4 w-4 text-emerald-900" />
              </div>
              <span className="font-bold text-sm text-yellow-100">ذكاء اصطناعي مُدمج</span>
            </div>
            <p className="text-xs leading-relaxed opacity-80">
              "مُيسّر" الذكي سيساعدك في إيجاد الشريك المثالي لتبادل المهارات فور دخولك.
            </p>
          </div>

          {/* Decorative SVG Shapes */}
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-emerald-500 rounded-full opacity-30 blur-3xl"></div>
          <div className="absolute top-20 -left-20 w-64 h-64 bg-teal-400 rounded-full opacity-20 blur-3xl"></div>
        </div>

        {/* Right Side: Auth Forms */}
        <div className="p-8 md:p-16 flex flex-col justify-center">
          <div className="text-center md:text-right mb-10">
            <h2 className="text-3xl font-black text-gray-900 mb-2">
              {mode === 'login' ? 'مرحباً بك مجدداً!' : 'أنشئ حسابك الجديد'}
            </h2>
            <p className="text-gray-500 font-medium">
              {mode === 'login' 
                ? 'سجل دخولك لتبدأ في تبادل المعرفة.' 
                : 'انضم لآلاف المبدعين العرب وابدأ التعلم.'}
            </p>
          </div>

          {/* Tab Switcher */}
          <div className="flex p-1.5 bg-gray-100 rounded-2xl mb-8">
            <button 
              onClick={() => setMode('login')}
              className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${mode === 'login' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              تسجيل الدخول
            </button>
            <button 
              onClick={() => setMode('signup')}
              className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${mode === 'signup' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              حساب جديد
            </button>
          </div>

          {/* Social Login */}
          <button 
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 border-2 border-gray-100 py-3.5 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 transition-all mb-6 group"
          >
            <svg className="w-5 h-5 group-hover:scale-110 transition-transform" viewBox="0 0 48 48">
              <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path>
              <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path>
              <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path>
              <path fill="#1976D2" d="M43.611,20.083L43.611,20.083L42,20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path>
            </svg>
            متابعة باستخدام جوجل
          </button>

          <div className="relative mb-8 text-center">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
            <span className="relative px-4 bg-white text-gray-400 text-xs font-bold uppercase tracking-widest">أو عبر البيانات</span>
          </div>

          <form onSubmit={handleAuth} className="space-y-5">
            {/* Method Switcher */}
            <div className="flex gap-4 mb-4">
              <button 
                type="button"
                onClick={() => setMethod('email')}
                className={`text-xs font-black pb-1 border-b-2 transition-all ${method === 'email' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-400'}`}
              >
                بالإيميل
              </button>
              <button 
                type="button"
                onClick={() => setMethod('phone')}
                className={`text-xs font-black pb-1 border-b-2 transition-all ${method === 'phone' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-400'}`}
              >
                برقم الجوال
              </button>
            </div>

            {method === 'email' ? (
              <div className="relative">
                <EnvelopeIcon className="absolute right-4 top-3.5 h-5 w-5 text-gray-400" />
                <input 
                  type="email" 
                  placeholder="البريد الإلكتروني"
                  required
                  className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-gray-50 border-0 focus:ring-2 focus:ring-emerald-500 outline-none text-sm transition-all"
                />
              </div>
            ) : (
              <div className="relative">
                <DevicePhoneMobileIcon className="absolute right-4 top-3.5 h-5 w-5 text-gray-400" />
                <input 
                  type="tel" 
                  placeholder="رقم الجوال (05xxxxxxx)"
                  required
                  className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-gray-50 border-0 focus:ring-2 focus:ring-emerald-500 outline-none text-sm transition-all"
                />
              </div>
            )}

            <div className="relative">
              <LockClosedIcon className="absolute right-4 top-3.5 h-5 w-5 text-gray-400" />
              <input 
                type="password" 
                placeholder="كلمة المرور"
                required
                className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-gray-50 border-0 focus:ring-2 focus:ring-emerald-500 outline-none text-sm transition-all"
              />
            </div>

            {mode === 'signup' && (
              <div className="flex items-center gap-2 px-1">
                <input type="checkbox" required className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500" />
                <label className="text-xs text-gray-500">
                  أوافق على <span className="text-emerald-600 font-bold underline cursor-pointer">الشروط والأحكام</span> ونظام النقاط.
                </label>
              </div>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className={`w-full py-4 rounded-2xl font-black text-white shadow-xl shadow-emerald-100 flex items-center justify-center gap-2 transition-all transform active:scale-95 ${isLoading ? 'bg-emerald-400 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700 hover:scale-[1.02]'}`}
            >
              {isLoading ? (
                <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  {mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}
                  <ArrowRightIcon className="h-5 w-5 transform rotate-180" />
                </>
              )}
            </button>
          </form>

          {mode === 'login' && (
            <button className="mt-6 text-xs font-bold text-gray-400 hover:text-emerald-600 transition-colors text-center w-full">
              هل نسيت كلمة المرور؟
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
