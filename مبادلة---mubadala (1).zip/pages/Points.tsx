
import React from 'react';
import { currentUser } from '../data/mockData';
import { TrophyIcon, ArrowUpCircleIcon, ArrowDownCircleIcon, InformationCircleIcon } from '@heroicons/react/24/solid';

const Points: React.FC = () => {
  const history = [
    { type: 'earn', amount: 2, user: 'ياسين علي', skill: 'اللغة الإنجليزية', date: 'منذ يومين' },
    { type: 'spend', amount: 1, user: 'سارة خالد', skill: 'تصميم واجهة المستخدم', date: 'منذ 5 أيام' },
    { type: 'earn', amount: 3, user: 'خالد منير', skill: 'JavaScript', date: 'منذ أسبوع' },
  ];

  return (
    <div className="space-y-6 md:pr-64">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-500 rounded-3xl p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <span className="text-emerald-100 text-sm font-medium">رصيد ساعاتك الحالي</span>
          <div className="flex items-center gap-3 mt-1">
            <TrophyIcon className="h-10 w-10 text-yellow-300" />
            <span className="text-5xl font-bold">{currentUser.points}</span>
            <span className="text-xl opacity-80 mt-4">ساعة</span>
          </div>
          <p className="mt-4 text-emerald-50 max-w-sm text-sm">
            لقد ساهمت بـ 15 ساعة من وقتك لتعليم الآخرين، وحصلت على رصيد للتعلم.
          </p>
        </div>
        <div className="absolute top-0 left-0 w-32 h-32 bg-white opacity-10 rounded-full -translate-x-16 -translate-y-16"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <InformationCircleIcon className="h-5 w-5 text-emerald-600" />
            كيف يعمل نظام النقاط؟
          </h2>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="bg-emerald-100 p-2 rounded-lg">
                <ArrowUpCircleIcon className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-bold text-gray-800">اكسب النقاط</h3>
                <p className="text-sm text-gray-500">كل ساعة تقضيها في تعليم شخص آخر تمنحك نقطة واحدة في رصيدك.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-2 rounded-lg">
                <ArrowDownCircleIcon className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-bold text-gray-800">استهلك النقاط</h3>
                <p className="text-sm text-gray-500">تعلم أي مهارة من الخبراء؛ كل ساعة تعلم تخصم نقطة واحدة من رصيدك.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
          <h2 className="text-xl font-bold mb-6">سجل العمليات</h2>
          <div className="space-y-4">
            {history.map((item, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${item.type === 'earn' ? 'bg-emerald-50' : 'bg-red-50'}`}>
                    {item.type === 'earn' ? (
                      <ArrowUpCircleIcon className="h-5 w-5 text-emerald-500" />
                    ) : (
                      <ArrowDownCircleIcon className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-800">
                      {item.type === 'earn' ? 'تعليم' : 'تعلم'} {item.skill}
                    </p>
                    <p className="text-xs text-gray-400">مع {item.user} • {item.date}</p>
                  </div>
                </div>
                <span className={`font-bold ${item.type === 'earn' ? 'text-emerald-600' : 'text-red-600'}`}>
                  {item.type === 'earn' ? '+' : '-'}{item.amount}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Points;
