
import React, { useEffect, useState } from 'react';
import { currentUser, mockUsers } from '../data/mockData';
import UserCard from '../components/UserCard';
import { getAIPrioritizedExperts } from '../services/geminiService';
import { SparklesIcon, AcademicCapIcon, ClockIcon, ChartBarIcon, ArrowRightIcon, UserGroupIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';
import { User } from '../types';

const Home: React.FC = () => {
  const [prioritizedUsers, setPrioritizedUsers] = useState<(User & { priorityReason?: string, matchScore?: number })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAI = async () => {
      setLoading(true);
      const priorities = await getAIPrioritizedExperts(currentUser, mockUsers);
      
      const enrichedUsers = priorities.map((p: any) => {
        const user = mockUsers.find(u => u.id === p.id);
        return user ? { ...user, priorityReason: p.priorityReason, matchScore: p.matchPercentage } : null;
      }).filter(Boolean);

      setPrioritizedUsers(enrichedUsers);
      setLoading(false);
    };
    initAI();
  }, []);

  return (
    <div className="space-y-12 pb-10">
      {/* Hero Section */}
      <section className="bg-emerald-600 rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl shadow-emerald-200">
        <div className="relative z-10 max-w-2xl text-right">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl text-xs font-bold mb-6 border border-white/20">
            <SparklesIcon className="h-4 w-4 text-yellow-300" />
            منصة "مبادلة": ذكاء اصطناعي لخدمة المعرفة
          </div>
          <h1 className="text-5xl md:text-6xl font-black mb-6 leading-tight">
            تبادل مهاراتك <br/> 
            <span className="text-emerald-300">واصنع مستقبلك</span>
          </h1>
          <p className="text-emerald-50 opacity-90 mb-10 text-xl leading-relaxed">
            محركنا الذكي يحلل احتياجاتك ويصلك بأفضل الموجهين في منطقتك لتعلم حقيقي ومجاني.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/search" className="bg-white text-emerald-700 px-10 py-5 rounded-3xl font-black shadow-xl hover:scale-105 transition-all">
              ابدأ الاستكشاف
            </Link>
          </div>
        </div>
        <AcademicCapIcon className="absolute -bottom-20 -left-20 h-96 w-96 text-white opacity-5" />
      </section>

      {/* AI Curation Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-gray-900 flex items-center gap-3">
            <SparklesIcon className="h-8 w-8 text-indigo-500" />
            مختارات "مُيسّر" لك
          </h2>
          <p className="text-gray-400 text-sm mt-1">بناءً على مهاراتك في {currentUser.skillsOffered[0]} واهتمامك بـ {currentUser.skillsSought[0]}</p>
        </div>
      </div>

      {/* AI Curated Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-gray-100 rounded-[2.5rem] animate-pulse"></div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {prioritizedUsers.map((user) => (
            <div key={user.id} className="relative group">
              <div className="absolute -top-4 -right-4 z-10 bg-indigo-600 text-white text-[10px] font-bold px-3 py-1.5 rounded-xl shadow-lg transform rotate-6">
                {user.priorityReason}
              </div>
              <UserCard user={user} onAction={() => window.location.hash = '#/messages'} />
              <div className="absolute bottom-4 left-4 text-[10px] font-black text-indigo-400 bg-white/80 px-2 py-1 rounded-lg">
                توافق {user.matchScore}%
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Global Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { label: 'رصيد نقاطك', value: currentUser.points, icon: ChartBarIcon, color: 'emerald' },
          { label: 'ساعات متاحة', value: currentUser.availableHours, icon: ClockIcon, color: 'blue' },
          { label: 'تقييم المجتمع', value: currentUser.rating, icon: SparklesIcon, color: 'yellow' },
          { label: 'مبادلاتك', value: currentUser.completedExchanges, icon: UserGroupIcon, color: 'purple' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-center">
            <stat.icon className={`h-8 w-8 text-${stat.color}-500 mb-2`} />
            <span className="text-2xl font-black">{stat.value}</span>
            <span className="text-[10px] font-bold text-gray-400 uppercase">{stat.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
