
import React, { useState, useEffect } from 'react';
import { mockUsers, currentUser, facilitatorBot } from '../data/mockData';
import { PaperAirplaneIcon, SparklesIcon, XMarkIcon, LightBulbIcon, AcademicCapIcon, ChatBubbleLeftRightIcon } from '@heroicons/react/24/solid';
import { generateSmartLearningPlan, getFacilitatorAdvice, chatWithFacilitator, getSmartChatActions } from '../services/geminiService';

const Messages: React.FC = () => {
  const [selectedChat, setSelectedChat] = useState(facilitatorBot);
  const [message, setMessage] = useState('');
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [learningPlan, setLearningPlan] = useState('');
  const [loadingPlan, setLoadingPlan] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [smartActions, setSmartActions] = useState<string[]>([]);
  
  const [allChatHistories, setAllChatHistories] = useState<{ [key: string]: any[] }>({
    'bot-1': [
      { id: 'bot-init', sender: 'them', text: 'أهلاً بك! أنا "مُيسّر"، رفيقك في رحلة التبادل. كيف يمكنني مساعدتك اليوم؟', time: 'الآن' }
    ],
    'u2': [
      { id: 'u2-1', sender: 'them', text: 'أهلاً أحمد، لفت نظري أنك تبحث عن تعلم الإنجليزية، هل أنت مهتم بتبادلها مقابل React؟', time: '10:00 ص' }
    ]
  });

  const chatHistory = allChatHistories[selectedChat.id] || [];

  // Logic: Update smart actions when chat context changes
  useEffect(() => {
    const updateActions = async () => {
      if (chatHistory.length > 0 && selectedChat.id !== 'bot-1') {
        const lastMsg = chatHistory[chatHistory.length - 1].text;
        const actions = await getSmartChatActions(lastMsg);
        setSmartActions(actions);
      } else {
        setSmartActions([]);
      }
    };
    updateActions();
  }, [chatHistory, selectedChat]);

  // Fix: Added missing handleOpenPlan function
  const handleOpenPlan = async () => {
    setLoadingPlan(true);
    const plan = await generateSmartLearningPlan(currentUser, selectedChat);
    setLearningPlan(plan || "لا يمكن إنشاء خطة حالياً.");
    setLoadingPlan(false);
  };

  const handleSend = async (customText?: string) => {
    const textToSend = customText || message;
    if (!textToSend.trim()) return;
    
    const userMsg = { id: Date.now().toString(), sender: 'me', text: textToSend, time: 'الآن' };
    const updatedHistory = [...chatHistory, userMsg];
    
    setAllChatHistories(prev => ({
      ...prev,
      [selectedChat.id]: updatedHistory
    }));
    
    setMessage('');
    setAiAdvice(null);

    if (selectedChat.id === 'bot-1') {
      setIsTyping(true);
      const geminiHistory = updatedHistory
        .filter(m => m.id !== 'bot-init')
        .map(m => ({
          role: m.sender === 'me' ? 'user' as const : 'model' as const,
          text: m.text
        }));

      const botResponse = await chatWithFacilitator(textToSend, geminiHistory);
      setIsTyping(false);
      const botMsg = { id: (Date.now() + 1).toString(), sender: 'them', text: botResponse, time: 'الآن' };
      setAllChatHistories(prev => ({
        ...prev,
        [selectedChat.id]: [...updatedHistory, botMsg]
      }));
    }
  };

  return (
    <div className="flex h-[calc(100vh-120px)] md:pr-64 bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm relative">
      {/* Sidebar - Chat List */}
      <div className="w-full md:w-80 border-l border-gray-100 flex flex-col">
        <div className="p-4 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
          <h2 className="font-bold text-xl">المحادثات</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          <button 
            onClick={() => setSelectedChat(facilitatorBot)}
            className={`w-full flex items-center gap-3 p-4 border-b border-gray-50 transition-all ${selectedChat.id === facilitatorBot.id ? 'bg-indigo-50 border-r-4 border-indigo-500' : ''}`}
          >
            <div className="h-12 w-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg">
              <SparklesIcon className="h-6 w-6" />
            </div>
            <div className="text-right flex-1">
              <p className="font-bold text-sm text-indigo-900">مُيسّر الذكي</p>
              <p className="text-xs text-indigo-500 truncate italic">تحدث معي لطلب المساعدة</p>
            </div>
          </button>

          {mockUsers.map(user => (
            <button 
              key={user.id}
              onClick={() => setSelectedChat(user)}
              className={`w-full flex items-center gap-3 p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors ${selectedChat.id === user.id ? 'bg-emerald-50 border-r-4 border-emerald-500' : ''}`}
            >
              <img src={user.avatar} className="h-12 w-12 rounded-2xl object-cover" />
              <div className="text-right flex-1">
                <p className="font-bold text-sm">{user.name}</p>
                <p className="text-xs text-gray-400 truncate">نشط في {user.location}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="hidden md:flex flex-1 flex-col bg-gray-50/50">
        <div className="p-4 bg-white border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {selectedChat.id === 'bot-1' ? (
              <div className="h-10 w-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
                <SparklesIcon className="h-5 w-5" />
              </div>
            ) : (
              <img src={selectedChat.avatar} className="h-10 w-10 rounded-xl" />
            )}
            <p className="font-bold">{selectedChat.name}</p>
          </div>
          {selectedChat.id !== 'bot-1' && (
            <button onClick={() => { setShowPlanModal(true); setLearningPlan(''); handleOpenPlan(); }} className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
              <AcademicCapIcon className="h-4 w-4" /> إنشاء خطة
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {chatHistory.map(msg => (
            <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] p-4 rounded-2xl text-sm ${msg.sender === 'me' ? 'bg-emerald-600 text-white shadow-md' : 'bg-white border border-gray-100 shadow-sm'}`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isTyping && <div className="text-xs text-indigo-400 font-bold animate-pulse">مُيسّر يكتب...</div>}
        </div>

        {/* Smart Actions Bar */}
        {smartActions.length > 0 && (
          <div className="px-6 py-2 flex gap-2 flex-wrap bg-gray-50 border-t border-gray-100">
            {smartActions.map((action, idx) => (
              <button 
                key={idx}
                onClick={() => handleSend(action)}
                className="text-[10px] font-bold bg-white border border-emerald-100 text-emerald-700 px-3 py-1.5 rounded-full hover:bg-emerald-50 transition-colors shadow-sm"
              >
                {action}
              </button>
            ))}
          </div>
        )}

        <div className="p-6 bg-white border-t border-gray-100">
          <div className="flex gap-2 relative">
            <input 
              type="text" 
              placeholder="اكتب رسالتك..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              className="flex-1 bg-gray-50 border-0 rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button onClick={() => handleSend()} className="bg-emerald-600 text-white p-4 rounded-2xl">
              <PaperAirplaneIcon className="h-6 w-6 transform rotate-180" />
            </button>
          </div>
        </div>
      </div>

      {/* Learning Plan Modal (Simplified for brevity but consistent) */}
      {showPlanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden p-8">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
               <SparklesIcon className="h-6 w-6 text-emerald-500" />
               خطة التعلم الذكية
            </h3>
            <div className="max-h-60 overflow-y-auto text-sm text-gray-600 whitespace-pre-wrap mb-6">
              {loadingPlan ? "مُيسّر يحلل البيانات..." : learningPlan}
            </div>
            <button onClick={() => setShowPlanModal(false)} className="w-full bg-emerald-600 text-white py-3 rounded-2xl font-bold">إغلاق</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Messages;
