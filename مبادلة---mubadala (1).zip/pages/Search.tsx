
import React, { useState } from 'react';
import { mockUsers, allSkills } from '../data/mockData';
import UserCard from '../components/UserCard';
import { MagnifyingGlassIcon, FunnelIcon } from '@heroicons/react/24/outline';

const Search: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('');

  const filteredUsers = mockUsers.filter(u => 
    (u.name.includes(searchTerm) || u.skillsOffered.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))) &&
    (selectedSkill === '' || u.skillsOffered.includes(selectedSkill))
  );

  return (
    <div className="space-y-6 md:pr-64">
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
        <h1 className="text-2xl font-bold mb-6">اكتشف المهارات</h1>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="absolute right-3 top-3.5 h-5 w-5 text-gray-400" />
            <input 
              type="text" 
              placeholder="ابحث عن مهارة أو مستخدم..."
              className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <FunnelIcon className="h-5 w-5 text-gray-500" />
            <select 
              className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
            >
              <option value="">كل المهارات</option>
              {allSkills.map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.length > 0 ? (
          filteredUsers.map(user => (
            <UserCard key={user.id} user={user} />
          ))
        ) : (
          <div className="col-span-full py-20 text-center text-gray-500">
            <MagnifyingGlassIcon className="h-12 w-12 mx-auto mb-4 opacity-20" />
            <p className="text-lg">لم نجد نتائج مطابقة لبحثك</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;
