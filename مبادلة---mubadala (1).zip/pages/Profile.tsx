
import React, { useState, useEffect } from 'react';
import { currentUser } from '../data/mockData';
import { PencilSquareIcon, CheckBadgeIcon, StarIcon, MapPinIcon, SparklesIcon, LightBulbIcon } from '@heroicons/react/24/outline';
import { suggestSkills, analyzeProfileStrength } from '../services/geminiService';

const Profile: React.FC = () => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [aiAdvice, setAiAdvice] = useState<string>('');
  const [loadingAdvice, setLoadingAdvice] = useState(false);

  useEffect(() => {
    const fetchAdvice = async () => {
      setLoadingAdvice(true);
      const advice = await analyzeProfileStrength(currentUser);
      setAiAdvice(advice);
      setLoadingAdvice(false);
    };
    fetchAdvice();
  }, []);

  const handleSuggest = async () => {
    const res = await suggestSkills(currentUser.skillsOffered[0]);
    setSuggestions(res);
  };

  return (
    <div className="space-y-6 md:pr-64 max-w-4xl pb-10">
      {/* Profile Header */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-emerald-500 to-emerald-700"></div>
        <div className="px-8 pb-8">
          <div className="relative -mt-12 flex items-end justify-between">
            <img src={currentUser.avatar} className="h-32 w-32 rounded-3xl border-4 border-white shadow-lg object-cover" />
            <button className="mb-4 flex items-center gap-2 px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl text-gray-700 font-semibold transition-colors">
              <PencilSquareIcon className="h-5 w-5" />
              تعديل الملف
            </button>
          </div>
          
          <div className="mt-6 flex flex-col md:flex-row gap-6">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-2">
                {currentUser.name}
                <CheckBadgeIcon className="h-6 w-6 text-blue-500" />
              </h1>
              <div className="flex gap-4 mt-2 text-gray-500">
                <div className="flex items-center gap-1">
                  <MapPinIcon className="h-4 w-4" />
                  <span className="text-sm">{currentUser.location}</span>
                </div>
                <div className="flex items-center gap-1 font-bold text-gray-700">
                  <StarIcon className="h-4 w-4 text-yellow-500" />
                  <span>{currentUser.rating}</span>
                </div>
              </div>
              <p className="mt-4 text-gray-600 leading-relaxed">{currentUser.bio}</p>
            </div>

            {/* AI Advisor Box */}
            <div className="md:w-72 bg-gradient-to-br from-blue-50 to-indigo-50 p-5 rounded-3xl border border-blue-100 relative overflow-hidden">
              <SparklesIcon className="absolute -top-2 -right-2 h-12 w-12 text-blue-200 opacity-50" />
              <h3 className="text-blue-800 font-bold text-sm mb-3 flex items-center gap-2">
                <LightBulbIcon className="h-4 w-4" />
                نصائح AI لملفك
              </h3>
              {loadingAdvice ? (
                <div className="space-y-2 animate-pulse">
                  <div className="h-3 bg-blue-200 rounded w-full"></div>
                  <div className="h-3 bg-blue-200 rounded w-5/6"></div>
                </div>
              ) : (
                <p className="text-xs text-blue-700 leading-relaxed whitespace-pre-line">
                  {aiAdvice}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Skills Section */}
        <div className="space-y-6">
          <section className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
            <h2 className="text-xl font-bold mb-4">مهارات أقدمها</h2>
            <div className="flex flex-wrap gap-2">
              {currentUser.skillsOffered.map(skill => (
                <span key={skill} className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl font-medium border border-emerald-100">
                  {skill}
                </span>
              ))}
              <button onClick={handleSuggest} className="px-4 py-2 border-2 border-dashed border-emerald-200 text-emerald-600 rounded-xl text-sm">
                + مهارات مقترحة
              </button>
            </div>
            {suggestions.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {suggestions.map(s => (
                  <button key={s} className="text-[10px] bg-white px-2 py-1 rounded-md border border-emerald-100 text-emerald-600">
                    {s}
                  </button>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Learning History */}
        <section className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
          <h2 className="text-xl font-bold mb-4">نشاط المبادلة</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-sm">تبادل مهارة التصميم</p>
                <p className="text-xs text-gray-500">مع سارة خالد • مكتمل</p>
              </div>
              <span className="text-emerald-600 font-bold">+1 ساعة</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-sm">تعلم المحادثة الإنجليزية</p>
                <p className="text-xs text-gray-500">مع ياسين علي • مكتمل</p>
              </div>
              <span className="text-blue-600 font-bold">-2 ساعة</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Profile;
