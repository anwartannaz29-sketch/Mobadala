
import React, { useState, useEffect, useRef } from 'react';
import { SparklesIcon, XMarkIcon, PaperAirplaneIcon, MinusIcon } from '@heroicons/react/24/solid';
import { chatWithFacilitator } from '../services/geminiService';

const GlobalFacilitator: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [history, setHistory] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: 'أهلاً بك! أنا "مُيسّر" مساعدك الذكي. كيف يمكنني مساعدتك في رحلة تعلمك اليوم؟' }
  ]);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, isTyping]);

  const handleSend = async () => {
    if (!message.trim()) return;

    const userMsg = message;
    setMessage('');
    setHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const response = await chatWithFacilitator(userMsg, history);
      setHistory(prev => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      setHistory(prev => [...prev, { role: 'model', text: 'عذراً، واجهت مشكلة تقنية. حاول مرة أخرى.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 md:bottom-8 left-8 z-50 bg-indigo-600 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-all group animate-bounce"
      >
        <SparklesIcon className="h-7 w-7" />
        <span className="absolute -top-12 right-0 bg-white text-indigo-600 text-[10px] font-bold px-3 py-1.5 rounded-xl shadow-md border border-indigo-100 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          تحتاج مساعدة؟ اسأل مُيسّر
        </span>
      </button>
    );
  }

  return (
    <div className={`fixed bottom-24 md:bottom-8 left-8 z-50 w-[350px] max-w-[90vw] bg-white rounded-[2rem] shadow-2xl border border-indigo-100 flex flex-col transition-all duration-300 ${isMinimized ? 'h-16' : 'h-[500px]'}`}>
      {/* Header */}
      <div className="p-4 bg-indigo-600 rounded-t-[2rem] flex items-center justify-between text-white shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-1.5 rounded-lg">
            <SparklesIcon className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm">مُيسّر الذكي</h3>
            <p className="text-[10px] opacity-80">متصل الآن</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setIsMinimized(!isMinimized)} className="p-1.5 hover:bg-white/10 rounded-lg">
            <MinusIcon className="h-5 w-5" />
          </button>
          <button onClick={() => setIsOpen(false)} className="p-1.5 hover:bg-white/10 rounded-lg">
            <XMarkIcon className="h-5 w-5" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Chat Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-indigo-50/30">
            {history.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tl-none shadow-md' 
                    : 'bg-white text-indigo-900 border border-indigo-100 rounded-tr-none shadow-sm'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white p-3 rounded-2xl rounded-tr-none shadow-sm flex gap-1 animate-pulse">
                  <div className="h-1.5 w-1.5 bg-indigo-300 rounded-full animate-bounce"></div>
                  <div className="h-1.5 w-1.5 bg-indigo-300 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="h-1.5 w-1.5 bg-indigo-300 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-white rounded-b-[2rem] border-t border-indigo-50">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="اسأل مُيسّر..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1 bg-gray-50 border-0 rounded-xl px-4 py-2.5 text-xs outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
              <button 
                onClick={handleSend}
                disabled={isTyping}
                className="bg-indigo-600 text-white p-2.5 rounded-xl hover:bg-indigo-700 disabled:bg-gray-300 transition-all shadow-md"
              >
                <PaperAirplaneIcon className="h-4 w-4 transform rotate-180" />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default GlobalFacilitator;
