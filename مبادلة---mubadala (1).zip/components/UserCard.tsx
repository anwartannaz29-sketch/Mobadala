
import React from 'react';
import { User } from '../types';
import { StarIcon, MapPinIcon, ClockIcon } from '@heroicons/react/24/solid';

interface UserCardProps {
  user: User;
  onAction?: () => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onAction }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-md transition-shadow">
      <div className="flex gap-4 items-start">
        <img src={user.avatar} alt={user.name} className="h-16 w-16 rounded-2xl object-cover" />
        <div className="flex-1">
          <h3 className="font-bold text-lg text-gray-800">{user.name}</h3>
          <div className="flex items-center gap-1 text-yellow-500 mb-1">
            <StarIcon className="h-4 w-4" />
            <span className="text-sm font-semibold">{user.rating}</span>
            <span className="text-xs text-gray-400">({user.completedExchanges} تبادل)</span>
          </div>
          <div className="flex items-center gap-1 text-gray-500 text-xs">
            <MapPinIcon className="h-3 w-3" />
            <span>{user.location}</span>
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        <div>
          <span className="text-xs font-semibold text-gray-400 block mb-1">يقدم:</span>
          <div className="flex flex-wrap gap-1">
            {user.skillsOffered.map(skill => (
              <span key={skill} className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md text-xs font-medium">
                {skill}
              </span>
            ))}
          </div>
        </div>
        <div>
          <span className="text-xs font-semibold text-gray-400 block mb-1">يبحث عن:</span>
          <div className="flex flex-wrap gap-1">
            {user.skillsSought.map(skill => (
              <span key={skill} className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md text-xs font-medium">
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <div className="flex items-center gap-1 text-gray-600">
          <ClockIcon className="h-4 w-4 text-emerald-500" />
          <span className="text-xs">{user.availableHours} ساعات متاحة</span>
        </div>
        <button 
          onClick={onAction}
          className="bg-emerald-600 text-white px-4 py-1.5 rounded-lg text-sm font-semibold hover:bg-emerald-700 transition-colors"
        >
          طلب تبادل
        </button>
      </div>
    </div>
  );
};

export default UserCard;
