
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  HomeIcon, 
  MagnifyingGlassIcon, 
  ChatBubbleLeftEllipsisIcon, 
  UserCircleIcon,
  AcademicCapIcon,
  TrophyIcon,
  ArrowRightOnRectangleIcon
} from '@heroicons/react/24/outline';
import { currentUser } from '../data/mockData';
import GlobalFacilitator from './GlobalFacilitator';

interface LayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, onLogout }) => {
  const location = useLocation();

  const navItems = [
    { name: 'الرئيسية', path: '/', icon: HomeIcon },
    { name: 'اكتشف', path: '/search', icon: MagnifyingGlassIcon },
    { name: 'الرسائل', path: '/messages', icon: ChatBubbleLeftEllipsisIcon },
    { name: 'النقاط', path: '/points', icon: TrophyIcon },
    { name: 'ملفي', path: '/profile', icon: UserCircleIcon },
  ];

  return (
    <div className="min-h-screen flex flex-col pb-20 md:pb-0">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-emerald-600 p-1.5 rounded-lg group-hover:scale-110 transition-transform">
              <AcademicCapIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-emerald-700 tracking-tight">مبادلة</span>
          </Link>

          <div className="flex items-center gap-4">
            <Link to="/points" className="hidden md:flex items-center gap-2 bg-emerald-50 hover:bg-emerald-100 px-4 py-1.5 rounded-full text-emerald-700 font-bold transition-colors">
              <TrophyIcon className="h-4 w-4" />
              <span className="text-sm">{currentUser.points} ساعة</span>
            </Link>
            
            <div className="flex items-center gap-3 border-r border-gray-100 pr-4 mr-2">
              <button 
                onClick={onLogout}
                className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                title="تسجيل الخروج"
              >
                <ArrowRightOnRectangleIcon className="h-5 w-5" />
              </button>
              <div className="hidden sm:block text-right">
                <p className="text-xs font-bold text-gray-800">{currentUser.name}</p>
                <p className="text-[10px] text-gray-400">مستوى متقدم</p>
              </div>
              <Link to="/profile">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name} 
                  className="h-10 w-10 rounded-xl border border-emerald-100 shadow-sm object-cover hover:scale-105 transition-transform"
                />
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex max-w-7xl mx-auto w-full relative">
        {/* Desktop Sidebar */}
        <div className="hidden md:block sticky top-16 h-[calc(100vh-64px)] w-64 p-6 border-l border-gray-100 bg-white/50 backdrop-blur-sm">
          <nav className="space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 group ${
                  location.pathname === item.path 
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' 
                    : 'text-gray-500 hover:bg-emerald-50 hover:text-emerald-600'
                }`}
              >
                <item.icon className={`h-6 w-6 transition-transform group-hover:scale-110 ${location.pathname === item.path ? 'text-white' : 'text-gray-400'}`} />
                <span className="font-bold text-sm">{item.name}</span>
              </Link>
            ))}
          </nav>
          
          <div className="mt-10 p-5 bg-gradient-to-br from-emerald-600 to-teal-500 rounded-[2rem] text-white shadow-xl shadow-emerald-100 relative overflow-hidden group">
            <AcademicCapIcon className="absolute -bottom-4 -left-4 h-24 w-24 text-white opacity-10 transform -rotate-12 group-hover:rotate-0 transition-transform" />
            <h3 className="font-bold text-sm mb-2 relative z-10">شارك معرفتك</h3>
            <p className="text-[10px] text-emerald-50 leading-relaxed relative z-10 mb-4">
              كل ساعة تعليم تساوي ساعة تعلم. نظام عادل للجميع.
            </p>
            <Link to="/search" className="relative z-10 block w-full text-center bg-white/20 backdrop-blur-md py-2 rounded-xl text-xs font-bold hover:bg-white/30 transition-colors">
              اكتشف المهارات
            </Link>
          </div>
        </div>

        {/* Dynamic Page Content */}
        <main className="flex-1 p-6 overflow-hidden">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-gray-100 flex justify-around py-3 z-50 px-4">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex flex-col items-center gap-1.5 transition-all ${
              location.pathname === item.path ? 'text-emerald-600' : 'text-gray-400 hover:text-emerald-500'
            }`}
          >
            <item.icon className={`h-6 w-6 ${location.pathname === item.path ? 'fill-emerald-100' : ''}`} />
            <span className="text-[10px] font-bold">{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* The Logical Final Touch: Floating AI Assistant accessible everywhere */}
      <GlobalFacilitator />
    </div>
  );
};

export default Layout;
