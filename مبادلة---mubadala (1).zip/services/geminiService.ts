
import { GoogleGenAI, Type } from "@google/genai";
import { User } from "../types";

// Always use the correct initialization parameter as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAIPrioritizedExperts = async (user: User, allUsers: User[]) => {
  try {
    const prompt = `
      بصفتك "مُيسّر"، محرك التوصية لمنصة "مبادلة". 
      قم بتحليل ملف المستخدم: ${user.name} (مهاراته: ${user.skillsOffered.join(',')}, اهتماماته: ${user.skillsSought.join(',')}).
      وقم بترتيب الخبراء التاليين بناءً على الفائدة القصوى لهذا المستخدم:
      ${allUsers.map(u => `ID: ${u.id}, الاسم: ${u.name}, يقدم: ${u.skillsOffered.join(',')}`).join('\n')}
      
      أرجع قائمة مرتبة بـ IDs فقط مع وصف قصير جداً (كلمتين) لسبب الأولوية.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              priorityReason: { type: Type.STRING },
              matchPercentage: { type: Type.NUMBER }
            },
            required: ["id", "priorityReason", "matchPercentage"]
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Gemini prioritizing error:", error);
    return [];
  }
};

export const getSmartChatActions = async (chatContext: string) => {
  try {
    const prompt = `
      بناءً على المحادثة التالية في منصة تبادل مهارات: "${chatContext}"
      اقترح 3 أزرار "إجراءات سريعة" يمكن للمستخدم الضغط عليها للرد أو التقدم في الاتفاق.
      اجعل الردود قصيرة وعملية باللغة العربية.
    `;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return ["طلب تفاصيل", "اقتراح موعد", "شكر الطرف الآخر"];
  }
};

export const chatWithFacilitator = async (userMessage: string, history: {role: 'user' | 'model', text: string}[]) => {
  try {
    const systemInstruction = `أنت "مُيسّر الذكي"، المساعد الرسمي لمنصة "مبادلة". 
    مهمتك مساعدة المستخدمين في تعلم كيفية استخدام الموقع، اقتراح مهارات، حل النزاعات، أو مجرد الدردشة حول التعلم التعاوني.
    رد دائماً باللغة العربية وبأسلوب ودود ومشجع وعملي جداً.`;

    const contents = history.map(h => ({
      role: h.role,
      parts: [{ text: h.text }]
    }));

    contents.push({
      role: 'user',
      parts: [{ text: userMessage }]
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents as any,
      config: { systemInstruction, temperature: 0.7 }
    });

    return response.text || "عذراً، أواجه مشكلة في التفكير حالياً.";
  } catch (error) {
    return "عذراً، أواجه مشكلة في التفكير حالياً.";
  }
};

export const generateSmartLearningPlan = async (user1: User, user2: User) => {
  try {
    const prompt = `أنت "مُيسّر". اقترح خطة تبادل مهارات بين ${user1.name} و ${user2.name} بناءً على مهاراتهما. رد باللغة العربية.`;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "لا يمكن إنشاء خطة حالياً.";
  } catch (error) {
    return "لا يمكن إنشاء خطة حالياً.";
  }
};

export const getFacilitatorAdvice = async (chatContext: string) => {
  try {
    const prompt = `أعط نصيحة قصيرة جداً باللغة العربية لمستخدم بناءً على سياق الدردشة: "${chatContext}"`;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || null;
  } catch (error) {
    return null;
  }
};

// Fix: Added missing suggestSkills function
export const suggestSkills = async (skill: string) => {
  try {
    const prompt = `بناءً على مهارة "${skill}"، اقترح 5 مهارات أخرى ذات صلة قد يرغب المستخدم في تعلمها أو تقديمها. رد بتنسيق JSON كمصفوفة من النصوص.`;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

// Fix: Added missing analyzeProfileStrength function
export const analyzeProfileStrength = async (user: User) => {
  try {
    const prompt = `حلل ملف المستخدم التالي وقدم 3 نصائح قصيرة لتحسينه لجذب المزيد من الشركاء للتبادل:
    الاسم: ${user.name}
    السيرة: ${user.bio}
    المهارات المعروضة: ${user.skillsOffered.join(', ')}
    المهارات المطلوبة: ${user.skillsSought.join(', ')}`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "لا توجد نصائح حالياً.";
  } catch (error) {
    return "لا توجد نصائح حالياً.";
  }
};
