
import { User } from '../types';

export const currentUser: User = {
  id: 'u1',
  name: 'أحمد محمود',
  avatar: 'https://picsum.photos/id/64/200/200',
  bio: 'مطور واجهات أمامية طموح، أحب مشاركة معرفتي في البرمجة وتعلم التصميم الجرافيكي.',
  skillsOffered: ['React', 'JavaScript', 'HTML/CSS'],
  skillsSought: ['تصميم واجهة المستخدم', 'اللغة الإنجليزية'],
  availableHours: 5,
  points: 10,
  rating: 4.8,
  completedExchanges: 12,
  location: 'القاهرة، مصر'
};

export const facilitatorBot: User = {
  id: 'bot-1',
  name: 'مُيسّر الذكي',
  avatar: 'AI_BOT_AVATAR', // Handled in UI
  bio: 'مساعدك الشخصي في منصة مبادلة. أنا هنا لمساعدتك في التخطيط لرحلتك التعليمية وحل مشكلات التبادل.',
  skillsOffered: ['إرشاد أكاديمي', 'تخطيط دروس', 'دعم فني'],
  skillsSought: [],
  availableHours: 999,
  points: 0,
  rating: 5.0,
  completedExchanges: 1000,
  location: 'سحابة مبادلة'
};

export const mockUsers: User[] = [
  {
    id: 'u2',
    name: 'سارة خالد',
    avatar: 'https://picsum.photos/id/65/200/200',
    bio: 'مصممة جرافيك بخبرة 3 سنوات. أرغب في تعلم أساسيات تطوير المواقع.',
    skillsOffered: ['تصميم واجهة المستخدم', 'Photoshop', 'Illustrator'],
    skillsSought: ['React', 'HTML/CSS'],
    availableHours: 3,
    points: 8,
    rating: 4.9,
    completedExchanges: 20,
    location: 'الرياض، السعودية'
  },
  {
    id: 'u3',
    name: 'ياسين علي',
    avatar: 'https://picsum.photos/id/66/200/200',
    bio: 'مدرس لغة إنجليزية. مهتم بتعلم البرمجة وتطوير تطبيقات الجوال.',
    skillsOffered: ['اللغة الإنجليزية', 'الترجمة'],
    skillsSought: ['Flutter', 'Python'],
    availableHours: 10,
    points: 15,
    rating: 4.7,
    completedExchanges: 8,
    location: 'عمان، الأردن'
  },
  {
    id: 'u4',
    name: 'ليلى حسن',
    avatar: 'https://picsum.photos/id/67/200/200',
    bio: 'خبيرة تسويق رقمي. أبحث عن شخص يعلمني العزف على العود.',
    skillsOffered: ['تسويق رقمي', 'SEO', 'إدارة محتوى'],
    skillsSought: ['موسيقى', 'عزف عود'],
    availableHours: 4,
    points: 5,
    rating: 4.5,
    completedExchanges: 5,
    location: 'دبي، الإمارات'
  }
];

export const allSkills = [
  'React', 'JavaScript', 'Python', 'HTML/CSS', 'Flutter',
  'تصميم واجهة المستخدم', 'Photoshop', 'Illustrator',
  'اللغة الإنجليزية', 'اللغة الفرنسية', 'الترجمة',
  'تسويق رقمي', 'SEO', 'إدارة محتوى',
  'موسيقى', 'عزف عود', 'رسم', 'طبخ'
];
